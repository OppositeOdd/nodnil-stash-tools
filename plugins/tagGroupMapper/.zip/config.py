# Stash Configuration for Tag-Group Mapper
# Update these values to match your Stash setup

STASH_URL = "http://localhost:9999"
STASH_API_KEY = ""  # Add your API key if authentication is required