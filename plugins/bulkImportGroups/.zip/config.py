# Configuration dictionary (replace with your actual config values)
config = {
    "api_key": "",
    "endpoint": "http://localhost:9999/graphql"
}